/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package core.controllers;

import core.controllers.utils.Response;
import core.controllers.utils.Status;
import core.models.Person;
import core.models.storage.Storage;

/**
 *
 * @author sebastiancampillo
 */
public class PersonController {
    public static Response createPerson(String id,String firstname,String lastname,String age,String gender){
        try{
            int idInt, ageInt;
            boolean genderB;
             try{
              idInt=Integer.parseInt(id);
              if(idInt<0){
                  return new Response("Id must be positive",Status.BAD_REQUEST);
              }
             }catch(NumberFormatException ex){
                 return new Response("id must be numeric",Status.BAD_REQUEST);
             }
             if(firstname.equals("")){
                 return new Response ("firstname must not be empty",Status.BAD_REQUEST);
             }
             if(lastname.equals("")){
                 return new Response ("lastname must not be empty",Status.BAD_REQUEST);
             }
             try{
              ageInt=Integer.parseInt(id);
              if(ageInt<0){
                  return new Response("age must be positive",Status.BAD_REQUEST);
              }
             }catch(NumberFormatException ex){
                 return new Response("age must be numeric",Status.BAD_REQUEST);
             }
             if(gender.equals("M")){
                 genderB=false;
             }else if(gender.equals("F")){
                 genderB=true;
             }else {
                 return new Response("Gender error",Status.BAD_REQUEST);
             }
             Storage storage=Storage.getInstance();
             if(!storage.addPerson(new Person(idInt, firstname, lastname, ageInt, genderB))){
                 return new Response("A person with that id already exists",Status.BAD_REQUEST);
             }
             return new Response("person created successfully",Status.CREATED);
        }catch(Exception ex){
            return new Response("Unexpected Error",Status.INTERNAL_SERVER_ERROR);
        }
    }
        public static Response readPerson(String id){
        return new Response("Not implemented",Status.NOT_IMPLEMENTED);
    }  
        public static Response updatePerson(String id,String firstname,String lastname,String age,String gender){
               return new Response("Not implemented",Status.NOT_IMPLEMENTED);
    }   
        public static Response deletePerson(String id){
               return new Response("Not implemented",Status.NOT_IMPLEMENTED);
    }
        
}
