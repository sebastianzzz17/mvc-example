/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package core.models;

/**
 *
 * @author sebastiancampillo
 */
public class Person {
   private final int id ; 
   private String fristname;
   private String lastname;
   private int age; 
   private boolean gender;

    public Person(int id, String fristname, String lastname, int age, boolean gender) {
        this.id = id;
        this.fristname = fristname;
        this.lastname = lastname;
        this.age = age;
        this.gender = gender;
    }

    public int getId() {
        return id;
    }

    public String getFristname() {
        return fristname;
    }

    public String getLastname() {
        return lastname;
    }

    public int getAge() {
        return age;
    }

    public boolean isGender() {
        return gender;
    }

    public void setFristname(String fristname) {
        this.fristname = fristname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setGender(boolean gender) {
        this.gender = gender;
    }

    @Override
    public String toString() {
        return  fristname + "" + lastname ;
    }
   
}
